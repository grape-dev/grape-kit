<h1 align="center">@grape-dev/grape-kit</h1>

<p align="center"><a href="README.md">English</a> | 简体中文</p>

<p align="center">
  <a href="https://www.npmjs.com/package/@grape-dev/grape-kit"><img src="https://img.shields.io/npm/v/@grape-dev/grape-kit" alt="npm version"></a>
  <a href="https://www.npmjs.com/package/@grape-dev/grape-kit"><img src="https://img.shields.io/npm/dm/@grape-dev/grape-kit" alt="npm downloads"></a>
  <a href="https://gitcode.com/grape-dev/grape-kit/blob/main/LICENSE"><img src="https://img.shields.io/npm/l/@grape-dev/grape-kit" alt="License: MIT"></a>
  <img src="https://img.shields.io/node/v/@grape-dev/grape-kit" alt="node">
  <a href="https://www.grapedev.cn/"><img src="https://img.shields.io/badge/grape-www.grapedev.cn-2563eb" alt="grape"></a>
</p>

<p align="center">
  <strong>Grape DevOps 流水线工具 × 主流 Agent</strong><br>
  在 opencode / CodeArts / WorkBuddy 等 Agent 里触发、观察、推进 Grape 多 agent DevOps 流水线，<br>
  并以<strong>接管会话（takeover）原语</strong>把云端节点原子让渡到本地——链不断、成果结构化交回。<br>
  <a href="https://www.npmjs.com/package/@grape-dev/grape-kit">npm</a> · <a href="https://www.grapedev.cn/">Grape 官网</a> · <a href="https://gitcode.com/grape-dev/grape-kit">源码仓库</a>
</p>

---

帮助各类 **Agent**（opencode / CodeArts / WorkBuddy / dsh 等）安全、结构化地使用 [Grape](https://gitcode.com/grape-dev/grape) —— 多 agent 协作的 AI Native DevOps 平台（vod → issue → coding → qa → sre）。

```
agent 宿主（MCP stdio：opencode / CodeArts / WorkBuddy / dsh…；其他 MCP 能力宿主可手动接线）
  → grape-kit（50 工具 · 原生 HTTP 直连 · Markdown 渲染 · initialize instructions 自举）
    → grape 服务端（流水线 / events / takeover 会话 API；CLI 仅 401 回退用）
```

## 能力总览（50 工具）

- **流水线遥控**：触发（唯一 A2A 入口）· 等待任务 · 任务状态 · 取消/恢复（带决策门）
- **需求与事件**：列表/详情/事件流/我的需求 · 建单 · 结构化交回模板
- **端云协同**（v0.3.2+ 核心）：**接管会话**把云端节点（如 coding）原子让渡到你的 Agent——签发 `tko_` 凭据（12h）并返回完整上下文（prompt/env/workspace/skill/history）；Agent 在本地干活、上报进度，按两阶段交回：`request-finish` 只报告完成，**在对话中经你确认**后再 `finish` 正式交回（结构化产物，链路保持完整）。
  - **凭据语义**：`tko_` 仅 repo_session 能力（继续节点工作 / 回报进度，**不含 git 凭据注入**）——`request-finish` 用 tko_ 即可，但**最终 `finish` 必须用用户级凭据（`grape_`）**，tko_ 调 finish 会 403 属预期边界。平台不提供 UI 确认按钮，确认只发生在你与 Agent 的对话里。
  - **技能物化**：接管建立时把平台下发的 `assets.skill` 落到本地工作区 `<cwd>/.grape-takeover-skills/<skill>/`（`SKILL.md` + `references/*`），渲染直接给出落盘路径（`技能已物化：<path>` + 文件数 + 是否含 references）——接管 prompt 里「技能已物化，直接读 SKILL.md」由指引变成事实。内联 `files` 与 `zip_url` 两种下发都支持（zip 走 Node 原生 `zlib` 零依赖解压，仅 store/deflate）；OBS 引用形态（`files` 条目只带 `__obs_key__`）先经资产内短签 URL 或 `GET /api/skills/by-id/{id}/download` 端点拉 zip 后同样解压物化——该端点**需用户级凭据（`grape_`）**，`tko_`/`tk_` 会话凭据调用必 403 属预期（失败行会按类别给出下一步）；两路都解析不出即显式 `failed`（reason：需服务端转 inline/zip_url 下发）且盘上零副作用，显式空串正文也按缺正文处理，不再静默落 0 字节空文件；旧平台未下发技能包时显式提示「本次未物化技能」，物化失败只告警、不作废已建立的会话。技能名过白名单、条目拒路径穿越/绝对路径/盘符/符号链接，恒不写 `.skills/`（worker 会清理该目录）。
  - 平台要求 weekly-11+；旧平台自动回退只读上下文。完整时序：[docs/20261114-takeover-architecture.md](docs/20261114-takeover-architecture.md)
  - **本地接管 workspace 覆盖**（Issue #37）：`grape_takeover_start` 支持可选 `workspace`（本机绝对路径）。解析优先级 `workspace` > `bundle.workspace.cwd_hint` > `process.cwd()`；技能物化目录、脚本 `{{CWD}}`、`GRAPE_AUTH_FILE` 均按本地路径解析，返回体带 `workspace_effective`；与云端 `cwd_hint` 不一致时渲染显式说明「云端路径在本机不存在」，不静默替换。`GRAPE_AUTH_FILE` 仅在含 `{{CWD}}` 或位于 `cwd_hint` 根内时才改写（平台默认 `<hint>/.grape-takeover-token` 属于后者）；自定义绝对路径与相对路径一律不改写，只提示核对/自行 source。`grape_git_credential` 复用同一会话根解析：`cwd_hint` 在本机存在时即越界边界（界外路径拒绝），本机不存在时显式 workspace 即会话根，并在返回体 `session_boundary` / `session_root_note` 明确披露「无云端越界边界」。
- **场景与仓库**：场景列表（市场 / 仓库副本）· 应用场景（建仓库副本，可选设默认）· 设仓库默认场景（决定新建需求走哪条流水线）· 托管仓库 · 同步仓库 · 项目模板 · 项目信息
- **搜索、知识与技能**：全局搜索（all/event/repo/agent）· 技能 ×6（列表/搜索/详情 + **上传/升级/跨 scope 复制**：本地预检、自动打 ZIP 带顶层目录、服务端 errors 全量透出）· 知识 ×2 · 仪表盘
  - `grape_get_skill_detail` 返回 **SKILL.md 全文**（去掉旧的 3000 字截断）；超过 **64KB（UTF-8 字节）** 时把正文**逐字节**写入临时文件，只返回 2000 字预览并显式标注「已截断，全文在 <path>」（含字节数）。
  - **能力握手与多技能 fail-closed**（Issue #32）：接管前先握手 `GET /api/health` 读取服务端 `version` + `capabilities[]`（进程内缓存 300s；`GRAPE_CAPABILITIES_TTL_MS` 可覆盖，`GRAPE_CAPABILITIES_REFRESH=1` 强制刷新）。节点 required 技能数 > 1 且服务端未声明 `skills.multi` 时，`grape_takeover_start` **拒绝接管**并返回稳定错误码 `E_CAP_UNSUPPORTED_MULTI_SKILL`，附 required 技能、服务端版本、已声明能力、能力来源、握手时间与三条升级指引——绝不静默只跑第一个技能。旧服务端（404 / 缺字段）视同仅支持单技能，单技能路径行为不变。`takeover_bundle.v2` **不隐含** `skills.multi`，客户端唯一判据是 `skills.multi`。握手请求同时声明 `client_capabilities`（`skills.multi=true`），供新服务端拦截旧客户端。
- **场景与仓库**：场景列表 · 应用场景 · 托管仓库 · 同步仓库 · 项目模板 · 项目信息
- **搜索、知识与技能**：全局搜索 · 技能 ×3 · 知识库 ×2 · 看板
- **Worker 接入**：把本机注册为 grape 执行引擎（`grape_worker_onboard`）
- **自管理**（v0.4.1+）：`grape_kit_version`（版本全景：本地 kit 版本 / npm 最新版 / grape CLI / 服务端连通性与契约版本 / 凭据来源）与 `grape_kit_check_update`（更新检查，支持 `dismiss` 3 天冷却）进程内只读直执行；`grape_kit_upgrade` / `grape_kit_install` / `grape_kit_uninstall` **只生成可复制命令**（自动识别安装形态：全局 npm / npx 缓存 / ClawHub / 项目本地依赖）——工具本身不执行任何变更，由用户确认后手动执行。只生成命令，无静默执行。

## 快速开始

> 省略 `--target` 时安装器自动检测本机宿主：
>
> - **未检测到**：交互终端弹出宿主选择菜单；非交互环境报错并列出受支持宿主。
> - **检测到一个**：直接装它。
> - **检测到多个**：全部安装（等价 `--target all`）；要装单个用 `--target <宿主>`。
> - `trae` 是**项目级**宿主：不进 `--target all`（全量模式无法确定项目），需在目标项目目录单独 `--target trae`；当前目录与 `$HOME` 相同时安装/卸载会被拒绝（不做用户级落盘）。

### 受支持宿主（10 个 --target）

| `--target` | 配置路径 | 格式 / 说明 |
|---|---|---|
| `opencode` | `~/.config/opencode/opencode.json(c)` | JSONC `mcp.grape` + skill 副本 |
| `workbuddy` | `~/.workbuddy/mcp.json` | JSON `mcpServers.grape-kit` + skill 副本 |
| `codearts` | `~/.codeartsdoer/codearts_cli.jsonc` | JSONC `mcp.grape-kit`，需在 IDE 内重启条目 |
| `officeace` | `~/.officeace/mcp.json` | 仅导入用清单（`mcpServers.grape-kit`） |
| `dsh` | `$DSH_HOME/profiles/web/cordis.patch.yml` | YAML 托管块 + skill 副本 |
| `codex` | `~/.codex/config.toml` | TOML `[mcp_servers.grape-kit]` + `[mcp_servers.grape-kit.env]` |
| `openclaw` | `~/.openclaw/openclaw.json` | JSON `mcp.servers`（兼容旧 `mcpServers`） |
| `hermes` | `~/.hermes/config.yaml` | YAML `mcp_servers` + skill 副本 |
| `atomcode` | `~/.atomcode/mcp.json`（`ATOMCODE_HOME` 可覆盖） | JSON `mcpServers` |
| `trae` | `<项目>/.trae/mcp.json`（`GRAPE_TRAE_CONFIG` 覆盖） | JSON `mcpServers`；仅项目级，路径对齐 Trae 官方 MCP 入口 |

前提：**Node ≥ 20**（无需 Python——v0.3.0 起原生 HTTP 直连）。凭据走环境变量：

```bash
export GRAPE_BASE_URL=https://www.grapedev.cn
export GRAPE_API_TOKEN=grape_xxx      # API Key：https://www.grapedev.cn/app/#account/profile
# 环境变量被清洗的宿主：写文件通道 ~/.grape/config.json {"token":"grape_xxx","base_url":"..."}
```

### 凭据优先级与 `auth init`

凭据写入收敛为单一入口；解析顺序固定，API 客户端、`doctor` 与接管脚本共用同一份语义：

1. `GRAPE_API_TOKEN_ONCE` —— runtime，仅当前进程（最高）
2. `GRAPE_API_TOKEN` / `GRAPE_BASE_URL` —— env 环境变量通道
3. `GRAPE_AUTH_FILE` 或 `~/.grape/config.json`（目录可用 `GRAPE_HOME` 覆盖）—— file 文件通道

```bash
# 写文件通道（权限 600、剥 BOM），并打印对应的 env 设置命令
npx -y @grape-dev/grape-kit auth init --token grape_xxx --base-url https://www.grapedev.cn
npx -y @grape-dev/grape-kit doctor     # 展示完整 runtime > env > file 优先级链（不回显 token）
```

`auth init` 在 `GRAPE_AUTH_FILE` 已设置时写它，否则写 `GRAPE_HOME/config.json`——写入目标始终与解析目标一致，写盘后回读校验。`doctor` 输出中命中档显示 `[ok]`；未命中/被覆盖档显示 `[--]`（信息行，无需处理）。

普通 `uninstall` 只移除宿主条目并提示残留凭据；加 `--clean-global` 才会删除 `~/.grape`（文件通道 + worker 注册产物）、用户级 `GRAPE_API_TOKEN`/`GRAPE_BASE_URL`（POSIX：从 rc 文件精确删除 `export` 行，备份只保留非凭据行——含凭据的备份等于换个文件名把 token 留盘；Windows 用 `reg delete`），并仅清理含 `node_modules/@grape-dev` 的 `_npx` 缓存条目。`--clean-global` 带不带 `--target` 均可执行（零宿主痕迹时也照跑全局清理）；`--dry-run` 先预览将删除项、不动盘：

```bash
npx -y @grape-dev/grape-kit uninstall --clean-global --dry-run   # 先预览
npx -y @grape-dev/grape-kit uninstall --clean-global
```

> 卸载口径：各宿主只删自己写的条目；若配置里只剩本次写入的空容器（如 hermes 的空 `mcp_servers`、JSON 宿主的空 `mcpServers`），则连同该文件一起删除（写前备份，`--dry-run` 同样披露）。

### OpenCode

```bash
npx -y @grape-dev/grape-kit install --target opencode
```

**装完重启会话**后生效。

```bash
npx -y @grape-dev/grape-kit doctor --target opencode --probe   # 逐项自检
npm install -g @grape-dev/grape-kit             # 更新（更新后重启会话）
npx -y @grape-dev/grape-kit uninstall --target opencode   # 卸载（备份配置）
```

### CodeArts Agent（华为云码道）

```bash
npx -y @grape-dev/grape-kit install --target codearts
```

写入 `~/.codeartsdoer/codearts_cli.jsonc`（全局）或 `<项目>/.codeartsdoer/codearts_cli.jsonc`（项目级）。装完需在 CodeArts：设置 → MCP工具 → 已安装 → grape-kit 点「重启」。

```bash
npx -y @grape-dev/grape-kit doctor --target codearts --probe
npx -y @grape-dev/grape-kit update --target codearts
npx -y @grape-dev/grape-kit uninstall --target codearts
```

### WorkBuddy

```bash
npx -y @grape-dev/grape-kit install --target workbuddy
```

写入 `~/.workbuddy/mcp.json`（`mcpServers.grape-kit`，走 npx 免全局安装）+ skill 落 `~/.workbuddy/skills/grape-remote/`。**重启宿主会话**即可加载连接器——无需手动「信任」（实测直接 spawn，宿主不弹授权）。凭据走环境变量，**不要**写进 mcp.json。

```bash
npx -y @grape-dev/grape-kit doctor --target workbuddy --probe
npx -y @grape-dev/grape-kit update --target workbuddy
npx -y @grape-dev/grape-kit uninstall --target workbuddy   # 移除条目+skill+receipt（配置自动备份）
```

### dsh（DeepSeek Harness）

```bash
npx -y @grape-dev/grape-kit install --target dsh
```

写入 `$DSH_HOME/profiles/web/cordis.patch.yml`（`$DSH_HOME` 缺省 `~/.dsh`）的**托管块**：`insert` 行含 `id: grape-kit`、`name: '@deepseek-ai/dsh-mcp-client'`、`transport: stdio`，`command: node` 指向本地 MCP 入口（入口脚本解析不到时回退 `npx`）；`grape-remote` skill 落到 `$DSH_HOME/skills/`。只改标记行之间的托管块，用户既有 patch 行逐字节保留，每次写入前自动备份。装完**重启 dsh 会话**加载新 patch。

`@deepseek-ai/dsh-mcp-client` 属 dsh web profile 侧依赖：安装器 best-effort 自动装，失败只提示不阻塞。自动安装未成功时手动补：

```bash
npx @deepseek-ai/dsh plugin --profile web add @deepseek-ai/dsh-mcp-client
corepack enable pnpm   # pnpm 缺失时先启用
```

```bash
npx -y @grape-dev/grape-kit doctor --target dsh --probe   # 三项：托管块 / skill 副本 / dsh-mcp-client
npx -y @grape-dev/grape-kit install --target dsh          # 升级后重新装配（幂等）
npx -y @grape-dev/grape-kit uninstall --target dsh        # 只删托管块 + skill 副本
```

> dsh 走 **MCP 最小路径**（50 工具）*零改动复用）；完整形态的原生 Cordis 插件由 [grape-dsh](https://gitcode.com/grape-dev/grape-dsh) 承载，二者并存。

### Codex CLI

```bash
npx -y @grape-dev/grape-kit install --target codex
```

写入 `~/.codex/config.toml` 的带标记托管块：`[mcp_servers.grape-kit]`（`command` / `args`，走 npx）加 `[mcp_servers.grape-kit.env]` 子表。只动托管块与 `grape-kit` 相关表，其它表与注释原样保留，每次写入先备份，重复安装逐字节幂等。装完**重启会话**。

```bash
npx -y @grape-dev/grape-kit doctor --target codex --probe
npx -y @grape-dev/grape-kit uninstall --target codex   # 只删托管块 / grape-kit 表
```

### Hermes

```bash
npx -y @grape-dev/grape-kit install --target hermes
```

写入 `~/.hermes/config.yaml` 的 `mcp_servers.grape-kit`（YAML，保注释与其它条目），并把 `grape-remote` skill 复制到 `~/.hermes/skills/`。Hermes 自带 MCP client，重启会话后条目即加载（旧「hermes 无 MCP client」说明已修正）。

```bash
npx -y @grape-dev/grape-kit doctor --target hermes --probe
npx -y @grape-dev/grape-kit uninstall --target hermes   # 删条目 + skill 副本
```

### Atomcode

```bash
npx -y @grape-dev/grape-kit install --target atomcode
```

写入 `~/.atomcode/mcp.json` 的 `mcpServers.grape-kit`；根路径可用 `ATOMCODE_HOME` 覆盖。其它连接器保留，每次写入先备份。

```bash
npx -y @grape-dev/grape-kit doctor --target atomcode --probe
npx -y @grape-dev/grape-kit uninstall --target atomcode
```

### Trae

```bash
npx -y @grape-dev/grape-kit install --target trae
```

写入项目级 `.trae/mcp.json` 的 `mcpServers.grape-kit`（Trae 官方 MCP 入口，需在项目根目录执行）；`GRAPE_TRAE_CONFIG` 可覆盖路径。按设计不触碰用户级 `~/.trae/mcp.json`：当前目录与 `$HOME` 相同时（此时项目级路径就是用户级路径）安装/卸载直接拒绝并提示到目标项目目录执行，`--target all` 也不包含 trae。其它 MCP server 保留，每次写入先备份。

```bash
npx -y @grape-dev/grape-kit doctor --target trae --probe
npx -y @grape-dev/grape-kit uninstall --target trae
```

### openclaw（ClawHub 市场）

```bash
openclaw plugins install clawhub:grape-kit@latest
```

`clawhub:` 为来源前缀（与 devkit 上架同款）。装后用插件 MCP 工具列表验证（50 工具）*。市场页：https://clawhub.ai/grape-dev/plugins/grape-kit

也可不经市场，直接用文件注册（与其它宿主同一套四件套）：

```bash
npx -y @grape-dev/grape-kit install --target openclaw   # ~/.openclaw/openclaw.json：mcp.servers.grape-kit（兼容旧 mcpServers）
npx -y @grape-dev/grape-kit uninstall --target openclaw # 加 --dry-run 预览
```

### 版本查询与更新（全宿主通用）

```bash
npx -y @grape-dev/grape-kit --version        # 版本查询
npm install -g @grape-dev/grape-kit          # 更新（更新后重启 Agent 会话）
npx -y @grape-dev/grape-kit uninstall        # 卸载（宿主自动检测）
npx -y @grape-dev/grape-kit uninstall --clean-global   # 同时清理 ~/.grape + 用户环境变量 + _npx 缓存
```

启动时自动检查 npm 新版本（24h 去重，`GRAPE_KIT_SKIP_UPDATE_CHECK=1` 关闭）；国内镜像同步滞后 1-3 天，最新版用 `--registry https://registry.npmjs.org/`。

然后直接对 Agent 说：

```
> 我有哪些单子在跑流水线？
> 帮 acme/demo 仓库的 #12 触发流水线，等到终态
> #12 的 coding 在跑——抢到本机来干，链不断                       ← takeover_start
> 干完了——上报平台，等我确认再正式交回                          ← progress + request-finish + finish（finish 需用户级凭据）
> 这个节点干不了——还给云端重跑，链不断                          ← takeover_abort
```

### 装完看能力地图（intro）

每次 `install` 成功都会打印一张**能力地图**：5 组能力说明，每组配一条可直接复制的示例问句。若尚未检测到凭据，同一段输出会先给 3 步 API Key 获取指引（去哪生成、`grape_` 前缀、写到哪），避免首次调用直接 401。

```bash
npx -y @grape-dev/grape-kit intro     # 随时重看能力地图
```

`intro` 与安装结束共用同一份常量，文案不会漂移。它不收 `--target`——能力地图与宿主无关，只读本地凭据状态；宿主相关命令见上面各宿主小节。

## 版本历史

| 版本 | 日期 | 要点 |
|---|---|---|
| 0.5.2-next.0 | 2026-11-26 | npm next 通道候选（`--tag next` 发布，latest 仍为 0.5.1，转正 0.5.2 另批）：本地接管 workspace 覆盖（#37）——`grape_takeover_start` 新增可选 `workspace` 入参，统一解析优先级 `args.workspace` > `bundle.workspace.cwd_hint` > `process.cwd()`（`resolveLocalWorkspace`），技能物化 / 接管脚本 `{{CWD}}` / `GRAPE_AUTH_FILE` 均以解析出的本地路径为准，返回体带 `workspace_effective`，与云端路径不一致显式披露、不静默替换 · `GRAPE_AUTH_FILE` 本地化（#37）——`{{CWD}}` 占位符按本地 workspace 填充，`cwd_hint` 根内云端路径按前缀替换为本地 workspace，自定义绝对路径与相对路径一律不改写（绝对路径提示本机可能不可读）· `grape_git_credential` 换券会话根收敛为单一解析器 `resolveCredentialSessionRoot`（#37）——`cwd_hint` 在本机存在时作可信越界边界（工作区外拒绝且不落盘），本地接管时显式 workspace 即会话根并明确降级披露，返回 `session_root` / `session_boundary` / `session_root_note` |
| 0.5.1 | 2026-11-25 | 0.5.1-next.0 转正版：package.json 新增 `mcpName` 归属字段（Official MCP Registry 验证要求，无功能影响）；next 通道候选全部载荷（#28 技能物化 / #30 派发判据 / #31 git 写回 / #32 capabilities 握手）随本版转正进入 latest |
| 0.5.1-next.0 | 2026-11-25 | npm next 通道候选（`--tag next` 发布，latest 仍为 0.5.0，转正 0.5.1 另批）：git 写回闭环（#31，工具面 48→50）——`grape_git_credential`（tko_ 换一次性本仓券 + GIT_ASKPASS 0600，过期自检）· `grape_create_pull`（只建 PR）；接管技能物化（#28）：`bundle.assets.skill` 落 `<cwd>/.grape-takeover-skills/<skill>/`（内联 files / zip_url 双通道，防符号链接与路径逃逸，解压 64MB 封顶 + CRC-32 校验）；客户端 capabilities 握手（#32）：接管前 `GET /api/health`，多技能节点遇未声明 `skills.multi` 的服务端按 `E_CAP_UNSUPPORTED_MULTI_SKILL` fail-closed；派发判据对齐（#30）：已派发 = `handoff.seq>0` / `already_dispatched`，兜底补发按场景链 `next` 推导；`grape_get_skill_detail` ≤64KB 全文直出（去掉 3000 字截断，超限逐字节落临时文件） |
| 0.5.0 | 2026-11-25 | 场景市场副本通道 + 技能上传批（#20）：`grape_apply_scene` 改走市场 apply 端点在仓库内创建场景副本（id/名未命中本地拒绝、不再静默回落 `default`，应用后回读确认，`set_default` 拆为第二步调用）· 新增 `grape_set_repo_scene`（写 `managed_repos.dev_scene`、写后回读，`clear=true` 清空回落智能推荐）· `grape_list_scenes` 仓库视角列 `custom-` 副本 · `grape_upload_skill` / `grape_update_skill` / `grape_convert_skill`（与服务端同口径本地预检 + 内置 ZIP 打包）· `grape_create_issue` 把 `description` 标为必填。新增 5 个安装目标（#26，`--target` 5→10）：`codex`（TOML 托管块、保注释）· `openclaw`（JSON、兼容旧 `mcpServers`）· `hermes`（YAML 保注释/保序 + `grape-remote` skill 副本）· `atomcode`（`ATOMCODE_HOME`）· `trae`（严格项目级、`$HOME` 闸门、不做用户级兜底）——均提供 install / uninstall（`--dry-run`）/ doctor（`--probe`）/ detect 四件套并纳入自动检测与 `--target all`；裸 doctor 汇总覆盖全部 10 宿主。自管理五工具（#27，工具面 39→48）：`grape_kit_version` 版本全景（本地 kit / npm latest / CLI 回退 / 服务端契约 / 凭据档位，各通道 best-effort 降级）· `grape_kit_check_update` 主动更新检查 + `dismiss` 3 天冷却（与启动期 24h 缓存解耦）· `grape_kit_upgrade` / `grape_kit_install` / `grape_kit_uninstall` 只生成可复制命令、绝不执行（安装形态自动识别：全局 npm / npx 缓存 / ClawHub / 项目本地 / 未知；`damaged` 宿主单列 blocked 并带出解析错误）；`takeover_finish` 只在平台确漏派发时补发（消除 `pending_dispatch` 假警报）；单测 270→395 |
| 0.4.0 | 2026-11-23 | DeepSeek Harness（dsh）适配（#21）：`install --target dsh` 以 **MCP stdio 托管 patch** 模式接入 dsh web profile —— 在 `$DSH_HOME/profiles/web/cordis.patch.yml` 写入带标记的 `insert` 托管块（`id: grape-kit` / `name: '@deepseek-ai/dsh-mcp-client'` / 本地脚本优先、`npx` 回退），`grape-remote` skill 落 `$DSH_HOME/skills/`，39 工具零改动复用；`uninstall --target dsh` 只删托管块 + skill 副本 · `doctor --target dsh` 三项检查（托管块 / skill 副本 / `dsh-mcp-client`）· `detect` 把 `~/.dsh` 纳入自动检测；依赖安装 best-effort（失败只给手动指引、退出码 0）。QA 硬化（PR #12）：托管块不完整或 patch 顶层为映射形状时拒绝写入（不静默删用户行、不写非法 YAML）· install→uninstall 逐字节往返保真 · 空文件与仅含托管块的备份清理；单测 257→270 |
| 0.3.10 | 2026-11-23 | 接管交回派发收口（#19）：派发指针只认 `next_seq`（`handoff_seq` 只是交回事件序号，不作派发证据）· 平台漏派时客户端兜底补发 coding→qa（与 trigger 同源 A2A 通道）并回填 `next_seq` · 受阻（`remote_may_still_run`／缺仓库-issue 标识／补发失败）落 `pending_dispatch` 待派发标记 + 可读告警，不再静默 grace；三处「未证实当成功」收口：交回未成功（`ok=false`／`changed=false`）不派发下一节点 · 白名单外节点名（如 `reviewer`）按「未知」上报不改写为 qa · 补发响应缺事件 `seq` 判未证实；#20 凭据/卸载批：`auth init` 唯一写入入口 · `uninstall --clean-global`（`--dry-run`、rc 备份不留凭据行、`_npx` 收窄到 grape-kit）· doctor 完整凭据优先级视图；单测 156→257 |
| 0.3.9 | 2026-11-23 | 端云接管全链路硬化（#12）：takeover_start 分支/MR 前置检查 · warnings 全量透出 · Node 跨平台接管三脚本（report/request-finish/finish）· 409 agent_mismatch 友好提示 · bundle 脚本 {{CWD}} 渲染 · doctor 凭据来源行；#17 修复批：intro 子命令 + 能力地图（无凭据先给 3 步 API Key 指引）· trigger_pipeline agent 参数（可从指定节点续跑）· doctor base_url 双通道并标注生效来源 · 审核三工具 native 崩溃修复；单测 136→156 |
| 0.3.8 | 2026-11-20 | 审核三工具（grape_review_pass / grape_review_reject / grape_confirm_done，工具面 36→39）· issues 表新增「仓库」列 · doctor 识别 ~/.grape/config.json 文件通道凭证（不再误报 FAIL） |
| 0.3.7 | 2026-11-20 | trigger/task_status 图形化渲染（触发即出节点链图 · 状态查询出卡片+进度条+下一步指引）· Quick Start 重构对齐 devkit 模式 + Capabilities 总览节 · 卸载清理 receipt · Codex/hermes 移出露出面 |
| 0.3.6 | 2026-11-19 | 流水线渲染支持 segments 事件流形态（真实 API 返回，不再回退原始 JSON）· 停滞状态「⚠️ 疑似停滞 N 分钟」透出到判读行 · 新增 segments 形态回归用例（单测 114→115） |
| 0.3.5 | 2026-11-19 | 宿主自动检测（按 workbuddy/codearts/officeace 痕迹）· 零宿主交互选择（不再静默兜底 opencode）· 干净环境自动建配置 + 三步上手引导 · 宿主矩阵补 codearts 专段与 ClawHub 渠道 |
| 0.3.4 | 2026-11-19 | codearts/officeace 两宿主安装（受支持宿主 2→4）· doctor 版本更新行（24h 去重、五态）· 条目引擎结构扫描加固 |
| 0.3.3 | 2026-11-18 | check_update 启动版本提醒 + CHANGELOG 生成器；401 回退最佳努力（#1） |
| 0.3.2 | 2026-11-17 | takeover 会话原语五工具（start/status/progress/finish/abort）；#2517 端侧适配（abort 重派失败告警 + 竞态警告渲染）；SKILL.md 双路径语义 |
| 0.3.1 | 2026-11-11 | cancel 三选决策门 · resume 事实复核 · search 契约收敛 · 结构化交回模板 |
| 0.3.0 | 2026-11-11 | 传输层原生化：原生 HTTP 直连，grape CLI/Python 变可选（401 回退通道） |
| 0.2.x | 2026-11-09 前 | 13→31 工具扩展 · worker_onboard · B1 接管闭环 |

逐版本完整记录（发布日期、工具面变化、行为修复，覆盖 npm 全部 25 条发布记录——含 `0.0.0-stage` 占位包与 next 通道候选 `0.5.2-next.0`（latest 仍为 0.5.1），0.2.3 从未发布）：[CHANGELOG.md](CHANGELOG.md)

## 设计原则

- **只触发、只观察、可推进、可接管**：A2A 编排默认服务端驱动；takeover 交回时以 `handoff.seq>0` / `handoff.reason=already_dispatched` 判已派发（`next_seq` 不作派发指针），双判据缺失且事件回读确认下一节点无 `a2a_event` 时，按**场景链 next**（如 coding→qa）由客户端兜底补发——且只在交回**本身成功**之后，交回未成功绝不把下一节点拉进一个未交回的任务；场景链外节点名按「未知」上报而不被改写；超出该范围保持平台原行为；接管以会话原语完成原子让渡与交回
- **scope 是第一道门禁**：契约 219 命令中 session_only 的 28 个（git-repo 等）对外部 token 必 403，直接排除；`tko_` 接管凭据仅 repo_session 能力、结束即吊销
- **无 UI 补偿**：工具返回即 Markdown 表格 / 节点链 / 事件时间线；`wait_task` 轮询带阶段摘要与超时提示

## Windows 注意事项

1. **编码**：grape CLI / MCP 输出 UTF-8，PowerShell 默认按 GBK 解码会显示乱码——先 `chcp 65001`，或设置 `$OutputEncoding = [Console]::OutputEncoding = [Text.UTF8Encoding]::new()`。
2. **BOM**：`~/.grape/config.json` 含 UTF-8 BOM 时 `JSON.parse` 会失败——用无 BOM 保存（VS Code「Save with Encoding → UTF-8」；PowerShell `Set-Content -Encoding utf8NoBOM`）。
3. **setx 不传播**：`setx GRAPE_API_TOKEN ...` 只对**新**进程生效，当前宿主会话读不到——设置后重启 Agent 宿主（opencode / CodeArts / WorkBuddy）或重新登录终端。

## 开发与测试

```bash
npm install

npm test        # 503 个单测（fake-grape 替身，不依赖真实服务端）

npm run smoke   # 真实 stdio JSON-RPC 往返：initialize → tools/list → tools/call
```

对真实服务端只读冒烟：

```bash
export GRAPE_BASE_URL=https://www.grapedev.cn GRAPE_API_TOKEN=grape_xxx
node scripts/live-smoke.mjs
```

## Roadmap

- [x] 组织仓归位（grape-dev/grape-kit）
- [x] 版本更新检测与升级提示（0.3.3 check_update）
- [x] install 目标 workbuddy（0.3.2）
- [ ] CI 门禁全面接入（当前提供 GitHub Actions 兼容 workflow，GitCode GoCI 转正后启用）
- [ ] install 目标扩展：codearts / officeace（integrations 三型）
- [x] install 目标 dsh（MCP stdio 托管 patch）；完整形态原生插件由 [grape-dsh](https://gitcode.com/grape-dev/grape-dsh) 承载，二者并存

## 相关链接

- [Grape 平台](https://www.grapedev.cn/) · [grape 主仓](https://gitcode.com/grape-dev/grape) · [grape-cli](https://gitcode.com/grape-dev/grape-cli) · [grape-dsh（DSH 宿主插件）](https://gitcode.com/grape-dev/grape-dsh)
- 端云协同架构与验证报告：[docs/20261114-takeover-architecture.md](docs/20261114-takeover-architecture.md)
- 贡献指南：[CONTRIBUTING.md](CONTRIBUTING.md) · 安全报告：[SECURITY.md](SECURITY.md) · 行为准则：[CODE_OF_CONDUCT.md](CODE_OF_CONDUCT.md) · 支持渠道：[SUPPORT.md](SUPPORT.md) · AI Agent 工作指引：[AGENTS.md](AGENTS.md)

## License

[MIT](LICENSE)
